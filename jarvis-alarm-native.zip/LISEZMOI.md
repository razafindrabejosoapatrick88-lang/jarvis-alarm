# JARVIS ALARM – PATRICK EDITION (version native Android)
Créateur : Mario.S.

## Méthode 1 – Sans PC : GitHub construit l'APK
1. Créez un compte gratuit sur github.com, puis un nouveau dépôt (New repository).
2. Envoyez TOUS les fichiers de ce dossier (y compris le dossier .github) via « Add file → Upload files ».
3. Onglet **Actions** → « Construire l'APK » → **Run workflow**.
4. Attendez environ 5 à 10 minutes, ouvrez l'exécution terminée, téléchargez **jarvis-alarm-apk** (zip contenant app-debug.apk).
5. Installez l'APK sur le téléphone.

## Méthode 2 – Avec PC (Node.js + Android Studio)
    npm install --legacy-peer-deps
    npx cap add android
    node patch-manifest.js
    npx cap sync android
    npx cap open android      (Build → Build APK(s))

## Au premier lancement sur le téléphone
- Autorisez les **Notifications**.
- Autorisez **Alarmes et rappels** (écran qui s'ouvre tout seul).
- Réglages Android → Batterie → JARVIS ALARM → **Sans restriction**.
- Installez « Synthèse vocale Google » + la voix française.

## Comment ça sonne
- Les alarmes sont programmées dans Android : la notification sonne même app fermée ou téléphone verrouillé.
- La VOIX et l'animation démarrent quand l'application s'ouvre (touchez la notification) ou si elle est déjà ouverte.
